
<?php

$hostname='localhost';
$username='root';
$password='';
$pdo = new PDO("mysql:host=$hostname;dbname=ecommerce",$username,$password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>