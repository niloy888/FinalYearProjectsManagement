<div class="col-xs-6 col-sm-3 sidebar-offcanvas" role="navigation">
    <ul class="list-group panel">
        <li class="list-group-item"><i class="glyphicon glyphicon-align-justify"></i> <b>eCommerce Dashboard</b></li>
        <li class="list-group-item"><input type="text" class="form-control search-query" placeholder="Search Something"></li>
        <li class="list-group-item"><a href="http://localhost/dreamLife/adminpanel/pages/home.php"><i class="glyphicon glyphicon-home"></i>Home </a></li>
        <li class="list-group-item"><a href="http://localhost/dreamLife/adminpanel/pages/product" ><i class="fa fa-cubes"></i>Products </a></li>
        <li class="list-group-item"><a href="http://localhost/dreamLife/adminpanel/pages/brands" ><i class="glyphicon glyphicon-list-alt"></i>Brands </a></li>
        <li class="list-group-item"><a href="http://localhost/dreamLife/adminpanel/pages/labels" ><i class="glyphicon glyphicon-signal "></i>Labels </a></li>
        <li class="list-group-item"><a href="http://localhost/dreamLife/adminpanel/pages/categories" ><i class="glyphicon glyphicon-tasks "></i>Categories </a></li>
        <li class="list-group-item"><a href="http://localhost/dreamLife/adminpanel/pages/banner" ><i class="glyphicon glyphicon-calendar"></i>Banner</a></li>
        <li class="list-group-item"><a href="http://localhost/dreamLife/adminpanel/pages/users" ><i class="fa fa-group"></i>Users List</a></li>
        <li class="list-group-item"><a href="http://localhost/dreamLife/adminpanel/pages/users" ><i class="fa fa-wifi"></i>Subcribers</a></li>

       <li class="list-group-item"><a href="http://localhost/dreamLife/adminpanel/logout.php" ><i class="glyphicon glyphicon-lock"></i>Logout</a></li>

    </ul>
</div>