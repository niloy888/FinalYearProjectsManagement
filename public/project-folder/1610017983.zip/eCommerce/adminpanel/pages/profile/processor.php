<?php
session_start();
if (!isset($_SESSION['AdminID']))
{
    header("Location: ../../?login");
    die();
}
?>
<?php
//$connection=mysqli_connect('localhost','root','','dreamlife');
include('../../elements/connection.php');
date_default_timezone_set('Asia/Dhaka');
$date = date('Y/m/d h:i:s', time());

$banner = new banner();

// Update Banner
if(isset($_POST['Update']))
    $banner::update($pdo,$date);

// Delete Banner
else if(isset($_REQUEST['delete']))
    $banner::delete($pdo,$_REQUEST['delete']);


class banner{
    function update($pdo,$date){
        $id = $_POST['id'];
        $name = $_POST['name'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['pass'];
        $phone = $_POST['phone'];
        $fname = 'name';

        $picture = "img/admin/".$_FILES['picture']['name'];
        $filename= $_FILES['picture']['tmp_name'];

        $sql = "update admins set picture='$picture',$fname='$name', username='$username', email='$email', password='$password', phone='$phone', modified_at='$date' where id='$id'";

        if((move_uploaded_file($filename, "../../".$picture))&&($pdo->query($sql))){
            header("location: ../profile?id=".$id);
        }

        else{
            $sql = "update admins set $fname='$name', username='$username', email='$email', password='$password', phone='$phone', modified_at='$date' where id='$id'";
            if($pdo->query($sql))
                header('location: ../profile?id='.$id);
            else echo "failed";
        }
    }

    function delete($pdo,$id){
        $sql = "delete from  banners where id = '$id'";
        if ($pdo->query($sql)) {
            header("location: ../banner");
        }
        else echo "failed";
    }
}
?>
