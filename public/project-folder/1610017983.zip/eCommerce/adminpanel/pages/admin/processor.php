<?php
session_start();
if (!isset($_SESSION['AdminID']))
{
    header("Location: ../../?login");
    die();
}
?>
<?php
include('../../elements/connection.php');
date_default_timezone_set('Asia/Dhaka');
$date = date('Y/m/d h:i:s', time());

$admin = new admin();

//Add Categories
if(isset($_POST['AddCat']))
    $admin::insert($pdo,$date);

//delete product
else if(isset($_REQUEST['delete']))
    $admin::delete($pdo,$_REQUEST['delete']);




class admin{
    function insert($pdo,$date){
        $name = $_POST['name'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['pass'];
        $sql = "insert into admins (name, username, email, password, created_at) VALUES ('$name','$username', '$email', '$password','$date')";
        if($pdo->query($sql))
            header('location: ../admin');
        else echo "failed";
    }
    function delete($pdo,$id){
        $id = $_REQUEST['delete'];
        if($pdo->query("DELETE FROM categories WHERE id='$id'"))
            header("location: ../categories");
        else
            echo "Failed";
    }
}
?>