<?php include('../../elements/connection.php');
session_start();
if (!isset($_SESSION['AdminID']))
{
    header("Location: ../../?login");
    die();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Order | eCommerce</title>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="shortcut icon" href="favicon_16.ico"/>
    <link rel="bookmark" href="favicon_16.ico"/>
    <!-- site css -->
    <link rel="stylesheet" href="../../dist/css/site.min.css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,800,700,400italic,600italic,700italic,800italic,300italic" rel="stylesheet" type="text/css">
    <!-- <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'> -->
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript" src="../../dist/js/site.min.js"></script>
    <style>
        #upic{
            width: 30px;
            height: 30px;
            border-radius: 100%;
        }
    </style>
</head>
<body>
<!--nav-->
<?php include('../../elements/nav.php'); ?>
<!--header-->
<div class="container-fluid">

    <!--documents-->
    <div class="row row-offcanvas row-offcanvas-left">
        <?php include('../../elements/sidepanel.php'); ?>
        <div class="col-xs-12 col-sm-9 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><a href="javascript:void(0);" class="toggle-sidebar">
                            <span class="fa fa-angle-double-left" data-toggle="offcanvas" title="Maximize Panel"></span></a>Orders List</h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Status</th>
                                        <th>Buyer</th>
                                        <th>Quantity</th>
                                        <th>Total Price</th>
                                        <th>Date</th>
                                        <th>Action</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    if(isset($_REQUEST['delete'])){
                                        $id=$_REQUEST['delete'];
                                        if($pdo->query("delete from checkout where id='$id'"));
                                    }

                                    else if(isset($_REQUEST['status'])) {
                                        $id = $_REQUEST['status'];
                                        if ($pdo->query("update checkout set status=1 where id='$id'")) ;
                                    }
                                    $data = $pdo->query("SELECT * FROM checkout order by id desc")->fetchAll();
                                    foreach ($data as $row) {
                                        $user = $pdo->query("SELECT * FROM users where id = ".$row['bid'])->fetch();
                                        $quantity = $pdo->query("SELECT * FROM carts where sid = ".$row['sid'])->rowCount();
                                        ?>

                                        <tr >
                                            <th><?php
                                                if($row['status'])
                                                    echo "Accepted";
                                                else echo "<a href='index.php?status=".$row['id']."'>Accept?</a>";
                                                ?></th>
                                            <th><a href="../users/profile.php?id=<?php echo $user['id']?>"><img id="upic" src="../../../public/<?php echo $user['picture']?>">
                                                    <?php echo $user['full_name']?></a></th>
                                            <th ><?php echo $quantity ?></th>
                                            <th> <?php echo $row['total_price']?> </th>
                                            <th> <?php echo $row['date']?> </th>
                                            <td>
                                                <a href="view.php?sid=<?php echo $row['sid']?>&bid=<?php echo $user['id']?>&date=<?php echo $row['date'] ?>">
                                                    VIEW <span class="glyphicon glyphicon-eye-open"></span>
                                                </a>


                                                <a href="index.php?delete=<?php echo $row['id']?>" id="<?php $row['sid']?>">
                                                    <span style="color:red;margin-left: 10px" class="glyphicon glyphicon-remove" aria-hidden="true"></span></a>

                                                <br>
                                            </td>
                                        </tr>

                                    <?php    } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div> <!--- End Panel Body -->
            </div>

            <div class="panel panel-default">
                <h1>eCommerce Footer</h1>

            </div>
        </div>
    </div><!-- panel body -->
</div>
</div><!-- content -->

</body>
</html>
