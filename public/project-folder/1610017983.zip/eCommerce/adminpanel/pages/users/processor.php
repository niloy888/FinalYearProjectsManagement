<?php
session_start();
if (!isset($_SESSION['AdminID']))
{
    header("Location: ../../?login");
    die();
}
?>
<?php
include('../../elements/connection.php');

$user = new user();

// Active
if(isset($_REQUEST['de']))
    $user::status($pdo,0,$_REQUEST['de']);

//Deactive
else  if(isset($_REQUEST['ac']))
    $user::status($pdo,1,$_REQUEST['ac']);

// Delete Product
else if(isset($_REQUEST['del']))
    $user::delete($pdo,$_REQUEST['del']);


class user{
    function delete($pdo,$id){
        $sql = "delete from  users where id = '$id'";
        if ($pdo->query($sql)) {
            header("location: ../users");
        }
        else echo "failed";
    }

    function status($pdo,$value,$id){
        $sql = "update  users set is_active='$value' where id = '$id'";
        if ($pdo->query($sql)) {
            header("location: ../users");
        }
        else echo "failed";
    }
}
?>
