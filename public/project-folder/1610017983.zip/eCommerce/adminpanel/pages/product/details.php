<?php include('../../elements/connection.php');
session_start();
if (!isset($_SESSION['AdminID']))
{
    header("Location: ../../?login");
    die();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Products Detail | eCommerce</title>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="shortcut icon" href="favicon_16.ico"/>
    <link rel="bookmark" href="favicon_16.ico"/>
    <!-- site css -->
    <link rel="stylesheet" href="../../dist/css/site.min.css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,800,700,400italic,600italic,700italic,800italic,300italic" rel="stylesheet" type="text/css">
    <!-- <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'> -->
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript" src="../../dist/js/site.min.js"></script>
    <style>
        img{

        }
    </style>
</head>
<body>
<!--nav-->
<?php include('../../elements/nav.php'); ?>
<!--header-->
<div class="container-fluid">

    <!--documents-->
    <div class="row row-offcanvas row-offcanvas-left">
        <?php include('../../elements/sidepanel.php'); ?>
        <div class="col-xs-12 col-sm-9 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><a href="javascript:void(0);" class="toggle-sidebar">
                            <span class="fa fa-angle-double-left" data-toggle="offcanvas" title="Maximize Panel"></span></a>Product Details</h3>
                </div>
                <div class="panel-body">
                    <?php
                    if(isset($_REQUEST['id'])) {
                        $id = $_REQUEST['id'];
                        $data = $pdo->query("SELECT * FROM  products where id = '$id'")->fetch();

                        ?>
                        <div class="col-md-8 col-md-offset-2">
                            <h5><?php echo $data['title']?></h5>
                            <div class="row" id="gradient">
                                <div class="col-md-4">
                                    <img src="../../../public/<?php echo $data['picture']?>" class="img-responsive">
                                    <a href="edit.php?edit=<?php echo $data['id']?>">
                                        <button type="button" class="btn btn-primary btn-block" style="margin-top: 10px">Edit</button>
                                    </a>
                                </div>
                                <div class="col-md-8" id="overview">
                                    <table class="table ">
                                        <thead>
                                        <tr><th>Product ID :</th><th><?php echo $data['id']?></th></tr>
                                        <tr><th>Brand ID :</th><th><?php echo $data['brand_id']?></th></tr>
                                        <tr><th>Lebel ID :</th><th><?php echo $data['lebel_id']?></th></tr>
                                        <tr><th>Title :</th><th><?php echo $data['title']?></th></tr>
                                        <tr><th>Short Description :</th><th><?php echo $data['short_description']?></th></tr>
                                        <tr><th>Description :</th><th><?php echo $data['description']?></th></tr>
                                        <tr><th>Total Sales :</th><th><?php echo $data['total_sales']?></th></tr>
                                        <tr><th>Product Type :</th><th><?php echo $data['product_type']?></th></tr>
                                        <tr><th>Is New :</th><th><?php
                                                if($data['is_new']==1)
                                                    echo "<span>YES</span>";
                                                else
                                                    echo "<span>NO</span>";
                                                ?></th></tr>
                                        <tr><th>Cost :</th><th><?php echo $data['cost']?></th></tr>
                                        <tr><th>MRP :</th><th><?php echo $data['mrp']?></th></tr>
                                        <tr><th>Special Price :</th><th><?php echo $data['special_price']?></th></tr>
                                        <tr><th>Soft Delete :</th><th><?php
                                                if($data['soft_delete']==1)
                                                    echo "<span>YES</span>";
                                                else
                                                    echo "<span>NO</span>";
                                                ?></th></tr>
                                        <tr><th>Is Draft :</th><th><?php
                                                if($data['is_draft']==1)
                                                    echo "<span>YES</span>";
                                                else
                                                    echo "<span>NO</span>";
                                                ?></th></tr>
                                        <tr><th>Is Active :</th><th><?php
                                                if($data['is_active']==1)
                                                    echo "<span>YES</span>";
                                                else
                                                    echo "<span>NO</span>";
                                                ?></th></tr>
                                        <tr><th>Created at :</th><th><?php echo $data['created_at']?></th></tr>
                                        <tr><th>Modified at :</th><th><?php echo $data['modified_at']?></th></tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                </div> <!--- End Panel Body -->
            </div>

            <div class="panel panel-default">
                <h1>eCommerce Footer</h1>

            </div>
        </div>
    </div><!-- panel body -->
</div>
</div><!-- content -->
</body>
</html>
