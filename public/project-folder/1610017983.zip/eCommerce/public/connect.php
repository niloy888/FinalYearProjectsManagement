<?php

$hostname='localhost';
$username='root';
$password='';
$dbname = 'ecommerce';
$pdo = new PDO("mysql:host=$hostname;dbname=ecommerce",$username,$password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>