<?php


namespace ecommerce\user;


class user
{
    public $db = null;

    function __construct($pdo)
    {
        $this->db = $pdo;
    }

    function information()
    {

    }

    function login($username, $password)
    {
        $match = $this->db->query("SELECT * FROM users WHERE (username='$username' OR email='$username') AND password='$password'")->rowCount();
        return $match;

    }
}
