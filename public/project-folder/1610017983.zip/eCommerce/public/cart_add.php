<?php
include_once 'includes/connection.php';
session_start();
$sid = $_SESSION['guest'];
echo $sid;
if(isset($_REQUEST['add']) or isset($_POST['add'])){
    $product_id = $_REQUEST['add'];
    if(isset($_POST['pid']))
        $product_id=$_POST['pid'];

    $data = $pdo->query("SELECT * FROM  products where id = '$product_id'")->fetch();
    $picture = $data['picture'];
    $product_title = $data['title'];
    $qty = 1;
    if(isset($_POST['qty']))
        $qty=$_POST['qty'];
    $unit_price = $data['mrp'];
    $total_price = $unit_price*$qty;

    $sql =  "insert into `carts` (`sid`,`product_id`,`picture`,`product_title`,`qty`,`unite_price`,`total_price`)
VALUES (:sid, :product_id,:picture,:product_title,:qty,:unit_price,:total_price)";
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':sid', $sid);
    $statement->bindValue(':product_id', $product_id);
    $statement->bindValue(':picture', $picture);
    $statement->bindValue(':product_title', $product_title);
    $statement->bindValue(':qty', $qty);
    $statement->bindValue(':unit_price', $unit_price);
    $statement->bindValue(':total_price', $total_price);

    $inserted = $statement->execute();
    if($inserted){
        if(isset($_REQUEST['all']))
        header('location: allproduct.php');
        else
        header('location: index.php');
    }
}

else if(isset($_POST['update'])){
    $id = $_POST['id'];
    $qty = $_POST['qty'];
    $sql = "update carts set qty = '$qty', total_price=unite_price*'$qty' where id = '$id'";
    if($pdo->query($sql))
        header('location: cart.php');
    else echo "failed";
}
else if(isset($_POST['delete'])){
    $id = $_POST['id'];
    $sql = "delete from carts where id = '$id'";
    if($pdo->query($sql))
        header('location: cart.php');
    else echo "failed";
}
?>