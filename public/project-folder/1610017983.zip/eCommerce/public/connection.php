<?php
 $connection=mysqli_connect('localhost','root', '','ecommerce')
     or die(mysqli_connect_error());
 ?>
