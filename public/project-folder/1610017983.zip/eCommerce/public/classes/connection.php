<?php


class connection
{
    function connect()
    {
        $hostname = 'localhost';
        $username = 'root';
        $password = '';
        $pdo = new PDO("mysql:host=$hostname;dbname=dreamlife", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    }
}
?>