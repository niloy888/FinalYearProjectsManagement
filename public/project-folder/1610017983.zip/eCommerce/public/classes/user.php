<?php


class user
{
    public $db=null;
    function __construct($var)
    {
        $this->db=$var;
    }
     function login($mail,$pass){
         $res =$this->db->query("SELECT * FROM users WHERE (username='$mail' OR email='$mail') AND password='$pass'")->rowCount();
         return $res;
     }
     function ProfileID($mail,$pass){
         $id = $this->db->query("SELECT id FROM users WHERE (username='$mail' OR email='$mail') AND password='$pass'")->fetch();
         return $id['id'];
     }
     function info($id){
         $data = $this->db->query("SELECT * FROM  users WHERE id = '$id'")->fetch();
         return $data;
     }
}