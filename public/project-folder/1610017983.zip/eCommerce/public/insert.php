<?php

date_default_timezone_set('Asia/Dhaka');
$date = date('Y/m/d h:i:s', time());

$chostname='localhost';
$cusername='root';
$cpassword='';

$name = $_POST['name'];
$username = $_POST['username'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$gender = $_POST['gender'];
$dob = $_POST['dob'];
$religion = $_POST['religion'];
$city = $_POST['city'];
$address = $_POST['address'];
$password = $_POST['password'];

$picture = "img/users/".$_FILES['picture']['name'];
$filename= $_FILES['picture']['tmp_name'];
move_uploaded_file($filename,$picture);
try {
    $dbh = new PDO("mysql:host=$chostname;dbname=ecommerce",$cusername,$cpassword);

    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //

    $sql = "INSERT INTO users (full_name,username,email,phone,gender,dob,religion,city,address,is_active,modified_at,created_at,password,picture)
		VALUES ('$name','$username','$email','$phone','$gender','$dob','$religion','$city','$address',1,'0000-00-00 00:00:00','$date','$password','$picture')";

    if ($dbh->query($sql)) {
        header("location: login.php?res=1");
        //echo 'su';
    }
    else{
        //header("location: index.php?res=0");
        echo 'failed';
    }

    $dbh = null;
}
catch(PDOException $e)
{
   echo $e->getMessage();
   echo 'failed';
}

?>
