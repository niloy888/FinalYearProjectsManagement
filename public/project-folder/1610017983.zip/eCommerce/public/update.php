<?php

date_default_timezone_set('Asia/Dhaka');
$date = date('Y/m/d h:i:s', time());

include('includes/connection.php');

$id = $_POST['id'];
$name = $_POST['name'];
$username = $_POST['username'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$gender = $_POST['gender'];
$dob = $_POST['dob'];
$religion = $_POST['religion'];
$city = $_POST['city'];
$address = $_POST['address'];
$password = $_POST['pass'];

$picture = "img/users/".$_FILES['picture']['name'];
$filename= $_FILES['picture']['tmp_name'];
$pic=move_uploaded_file($filename,$picture);

    if($pic)
        $sql = "UPDATE users SET full_name='$name',username='$username',email='$email',phone='$phone',gender='$gender',dob='$dob',religion='$religion',
city='$city',address='$address',modified_at='$date',password='$password',picture='$picture' where id='$id'";
    else
        $sql = "UPDATE users SET full_name='$name',username='$username',email='$email',phone='$phone',gender='$gender',dob='$dob',religion='$religion',
city='$city',address='$address',modified_at='$date',password='$password' where id='$id'";

    if ($pdo->query($sql)) {
        header("location: profile.php?res=1");
    }
    else{
        header("location: profile.php?res=0");
    }


?>
