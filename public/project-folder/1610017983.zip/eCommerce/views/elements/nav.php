<!-- Header section -->
	<header class="header-section" style="margin-top: -152px">
		<div class="header-top">
			<div class="container">
				<div class="row" style="margin-right: -222px;margin-left: 464px !important">
					<div>
						<ul class="top-nav">
                           <li style="position: relative;left: -400px;top: 160px;list-style: none">
                               <a href="tel:+123-456-7890"><i class="fa fa-phone-square ml-2"></i>+8801515682746</a>
                           </li>
                           <li style="position: relative;left: -590px;top: 135px;list-style: none">
                               <a href="mailto:mail@ecom.com"><i class="fa fa-envelope mr-2"></i>pucian@gmail.com</a>
                           </li>
                        </ul>
					</div>
					
					<div class="col-lg-2 text-center text-lg-left" style="position:relative;left: -987px;top: 123px;">
						<!-- logo -->
						<a href="./index.html" class="site-logo">
							<img src="img/logo.png" alt="">
						</a>
					</div>
					<div class="col-xl-6 col-lg-5" style="position: relative;top:25px">
						<form class="header-search-form">
							<input type="text" placeholder="Search on Product....">
							<button><i class="flaticon-search"></i></button>
						</form>
					</div>
					<div class="col-xl-4 col-lg-5">
						<div class="user-panel">
							<div class="up-item" style="position: relative;left: -15px;top: 33px">
                                <?php
                                if(!isset($_SESSION['UserID'])) {
                                    echo "<i class='flaticon-profile'></i>";
                                    echo "<a href='login.php'>Sign in</a> or <a href='SingUp.php'>Create Account</a>";
                                }
                                else{
                                    include('connect.php');
                                    $UserID = $_SESSION['UserID'];
                                    $data = $pdo->query("SELECT * FROM users WHERE id = '$UserID'")->fetch();
                                    echo "<img src=".$data['picture']." style='width:40px; height: 40px;border-radius: 100%'>";
                                    echo "<a href='profile.php'> ".$data['full_name']."</a> || <a href='logout.php'>Logout</a>";
                                }
								?>
							</div>
							<div class="up-item" style="position: relative;left: 240px">
								<div class="shopping-card">
                                    <?php
                                    include_once 'includes/connection.php';
                                    $sid = $_SESSION['guest'];
                                    $data = $pdo->query("SELECT id FROM  carts where sid = '$sid'")->rowCount();
                                    ?>
									<i class="flaticon-bag"></i>
									<span><?php echo $data; ?></span>
								</div>
								<a href="cart.php">Cart</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<nav class="main-navbar" style="position: relative;top: 17px">
			<div class="container">
				<!-- menu -->
				<ul class="main-menu">
					<li><a href="index.php">Home</a></li>
                    <li><a href="allproduct.php">All Product</a></li>
                    <li><a href="#">Categories</a>
                        <ul class="sub-menu">
                            <li><a href="laptop.php">Laptop</a></li>
                            <li><a href="Laptop.php">Desktop</a></li>
                            <li><a href="laptop.php">Electronics</a></li>
                            <li><a href="laptop.php">Furniture</a></li>
                            <li><a href="laptop.php">Jewellery</a></li>
                        </ul>
                    </li>
					<li><a href="#">Pages</a>
						<ul class="sub-menu">
							<li><a href="./product.php">Product Page</a></li>
							<li><a href="./category.php">Category Page</a></li>
							<li><a href="./cart.php">Cart Page</a></li>
							<li><a href="./checkout.php">Checkout Page</a></li>
							<li><a href="./contact.php">Contact Page</a></li>
						</ul>
					</li>
					<li><a href="myorder.php">My Order</a></li>
					<li><a href="contact.php">Contact Us</a></li>
				</ul>
			</div>
		</nav>
	</header>
	<!-- Header section end -->