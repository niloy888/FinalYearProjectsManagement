<section class="banner-section">
    <div class="container">
        <div class="banner set-bg" data-setbg="img/banner-bg.jpg">
            <div class="tag-new">NEW</div>
            <span>eCommerce</span>
            <h2>PUCIAN'S e-COMMERCE</h2>
            <a href="#" class="site-btn">SHOP NOW</a>
        </div>
    </div>
</section>